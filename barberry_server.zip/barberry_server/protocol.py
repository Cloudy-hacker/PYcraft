# -*- coding: utf-8 -*-
import json

def encode_message(data):
    message = json.dumps(data, ensure_ascii=False).encode('utf-8')
    return len(message).to_bytes(4, 'big') + message

def decode_message(raw):
    return json.loads(raw.decode('utf-8'))
