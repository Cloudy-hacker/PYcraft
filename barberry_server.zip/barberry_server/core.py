# -*- coding: utf-8 -*-
"""
Barberry Server 2.0 — ядро
Сохранение банов, вайтлиста, управление мирами
"""

import asyncio
import time
import json
import os
from world import World
from player import Player
from save import SaveManager
from network import NetworkHandler
from protocol import encode_message

BANS_FILE = "bans.json"
WHITELIST_FILE = "whitelist.json"
WORLDS_DIR = "worlds"

class BarberryServer:
    def __init__(self, config):
        self.config = config
        self.world = World(size=config.get("world_size",100))
        self.world_name = "default"
        self.players = {}
        self.next_player_id = 1
        self.save_manager = SaveManager(worlds_dir=WORLDS_DIR)
        self.network_handler = NetworkHandler(self)
        self.running = False
        self.day_timer = 0
        self.save_timer = 0
        self.player_roles = {}
        self.muted_players = set()
        self.frozen_players = set()
        self.whitelist = set()
        
        self.banned_players = set()
        self.banned_ips = set()
        self.banned_hashes = set()
        
        self._load_bans()
        self._load_whitelist()
        self._load_world(self.config.get("default_world", "default"))
    
    def _load_bans(self):
        if os.path.exists(BANS_FILE):
            try:
                with open(BANS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.banned_players = set(data.get("players", []))
                self.banned_ips = set(data.get("ips", []))
                self.banned_hashes = set(data.get("hashes", []))
                print(f"[Core] Загружено банов: {len(self.banned_players)} ников, "
                      f"{len(self.banned_ips)} IP, {len(self.banned_hashes)} CID")
            except Exception as e:
                print(f"[Core] Ошибка загрузки банов: {e}")
    
    def _save_bans(self):
        try:
            data = {
                "players": list(self.banned_players),
                "ips": list(self.banned_ips),
                "hashes": list(self.banned_hashes)
            }
            with open(BANS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[Core] Ошибка сохранения банов: {e}")
    
    def _load_whitelist(self):
        if os.path.exists(WHITELIST_FILE):
            try:
                with open(WHITELIST_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.whitelist = set(data.get("players", []))
                print(f"[Core] Загружено вайтлист: {len(self.whitelist)} игроков")
            except Exception as e:
                print(f"[Core] Ошибка загрузки вайтлиста: {e}")
    
    def _save_whitelist(self):
        try:
            data = {"players": list(self.whitelist)}
            with open(WHITELIST_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[Core] Ошибка сохранения вайтлиста: {e}")
    
    def _load_world(self, world_name):
        self.world_name = world_name
        self.world = self.save_manager.load_world(world_name)
        print(f"[Core] Загружен мир: {world_name}")
    
    def _save_world(self):
        self.save_manager.save_world(self.world, self.world_name)
    
    def get_world_list(self):
        worlds = []
        if os.path.exists(WORLDS_DIR):
            for f in os.listdir(WORLDS_DIR):
                if f.endswith(".json"):
                    worlds.append(f[:-5])
        return worlds
    
    def create_world(self, world_name):
        if world_name in self.get_world_list():
            return False, "Мир уже существует"
        new_world = World(size=self.config.get("world_size", 100))
        self.save_manager.save_world(new_world, world_name)
        return True, f"Мир '{world_name}' создан"
    
    def delete_world(self, world_name):
        filepath = os.path.join(WORLDS_DIR, f"{world_name}.json")
        if os.path.exists(filepath):
            os.remove(filepath)
            return True, f"Мир '{world_name}' удалён"
        return False, "Мир не найден"
    
    def check_integrity(self, client_hash):
        if not self.config.get("online", False):
            return True
        expected = self.config.get("client_hash", "")
        if not expected:
            return True
        return client_hash == expected
    
    def add_player(self, nickname, client_hash=None, writer=None, ip=None):
        if ip and ip in self.banned_ips:
            return None, "Ваш IP забанен на этом сервере"
        
        if client_hash and client_hash in self.banned_hashes:
            return None, "Ваш клиент (CID) забанен на этом сервере"
        
        if self.config.get("online", False):
            if not self.check_integrity(client_hash):
                return None, "Проверка неприкосновенности провалена"
        
        if nickname in self.banned_players:
            return None, "Вы забанены на этом сервере"
        
        if self.config.get("whitelist_enabled", False) and nickname not in self.whitelist:
            return None, "Вас нет в белом списке"
        
        if len(self.players) >= self.config.get("max_players", 10):
            return None, "Сервер заполнен"
        
        spawn_x, spawn_y = self.world.get_spawn_point()
        player = Player(self.next_player_id, nickname, spawn_x, spawn_y, writer)
        player.ip = ip
        player.client_hash = client_hash
        self.players[player.id] = player
        self.next_player_id += 1
        
        if nickname not in self.player_roles:
            self.player_roles[nickname] = "guest"
        player.role = self.player_roles.get(nickname, "guest")
        
        print(f"[Core] + {nickname} (ID:{player.id}, Role:{player.role}, IP:{ip})")
        return player, None
    
    def remove_player(self, player):
        if player.id in self.players:
            del self.players[player.id]
            print(f"[Core] - {player.nickname}")
            self.broadcast({"type":"player_leave","player_id":player.id}, exclude=player)
    
    def set_role(self, nickname, role):
        if role in ["guest","player","op"]:
            self.player_roles[nickname] = role
            for p in self.players.values():
                if p.nickname == nickname:
                    p.role = role
                    p.send({"type":"role_update","role":role})
            return True
        return False
    
    def broadcast(self, message, exclude=None):
        data = encode_message(message)
        for player in self.players.values():
            if player != exclude and player.writer:
                try:
                    player.writer.write(data)
                except:
                    pass
    
    def execute_console_command(self, cmd_str):
        if not cmd_str.startswith("/"):
            print(f"[Console] {cmd_str}")
            return
        
        parts = cmd_str[1:].strip().split()
        if not parts:
            return
        cmd = parts[0].lower()
        args = parts[1:]
        
        if cmd == "deop":
            if not args:
                print("Использование: /deop <player>")
                return
            self.set_role(args[0], "player")
            print(f"[Console] {args[0]} больше не оператор")
        elif cmd == "op":
            if not args:
                print("Использование: /op <player>")
                return
            self.set_role(args[0], "op")
            print(f"[Console] {args[0]} теперь оператор")
        elif cmd in ["player", "pl"]:
            if not args:
                print("Использование: /player <ник>")
                return
            self.set_role(args[0], "player")
            print(f"[Console] {args[0]} теперь обычный игрок")
        elif cmd == "guest":
            if not args:
                print("Использование: /guest <ник>")
                return
            self.set_role(args[0], "guest")
            print(f"[Console] {args[0]} теперь гость")
        elif cmd == "kick":
            if not args:
                print("Использование: /kick <player> [reason]")
                return
            target = args[0]
            reason = " ".join(args[1:]) or "Без причины"
            kicked = False
            for p in list(self.players.values()):
                if p.nickname == target:
                    p.send({"type":"kick","message":f"Вы были кикнуты: {reason}"})
                    try:
                        p.writer.close()
                    except:
                        pass
                    self.remove_player(p)
                    print(f"[Console] {target} кикнут: {reason}")
                    kicked = True
                    break
            if not kicked:
                print(f"[Console] Игрок {target} не найден")
        elif cmd == "ban":
            if not args:
                print("Использование: /ban <player> [reason]")
                return
            target = args[0]
            reason = " ".join(args[1:]) or "Без причины"
            self.banned_players.add(target)
            for p in list(self.players.values()):
                if p.nickname == target:
                    if getattr(p, 'ip', None):
                        self.banned_ips.add(p.ip)
                        print(f"[Console] Забанен IP: {p.ip}")
                    if getattr(p, 'client_hash', None):
                        self.banned_hashes.add(p.client_hash)
                        print(f"[Console] Забанен CID: {p.client_hash[:16]}...")
                    p.send({"type":"kick","message":f"Вы забанены: {reason}"})
                    try:
                        p.writer.close()
                    except:
                        pass
                    self.remove_player(p)
                    break
            self._save_bans()
            print(f"[Console] {target} забанен: {reason}")
        elif cmd == "unban":
            if not args:
                print("Использование: /unban <ник> или /unban #<номер>")
                return
            if args[0].startswith("#"):
                try:
                    num = int(args[0][1:]) - 1
                    all_bans = list(self.banned_players) + list(self.banned_ips) + list(self.banned_hashes)
                    if 0 <= num < len(all_bans):
                        ban_to_remove = all_bans[num]
                        self.banned_players.discard(ban_to_remove)
                        self.banned_ips.discard(ban_to_remove)
                        self.banned_hashes.discard(ban_to_remove)
                        self._save_bans()
                        print(f"[Console] Бан #{num+1} снят: {ban_to_remove}")
                    else:
                        print(f"[Console] Неверный номер. Всего банов: {len(all_bans)}")
                except ValueError:
                    print("[Console] Неверный номер")
            else:
                self.banned_players.discard(args[0])
                self._save_bans()
                print(f"[Console] {args[0]} разбанен (ник)")
        elif cmd == "unbanip":
            if not args:
                print("Использование: /unbanip <ip>")
                return
            self.banned_ips.discard(args[0])
            self._save_bans()
            print(f"[Console] IP {args[0]} разбанен")
        elif cmd == "unbancid":
            if not args:
                print("Использование: /unbancid <hash>")
                return
            self.banned_hashes.discard(args[0])
            self._save_bans()
            print(f"[Console] CID {args[0][:16]}... разбанен")
        elif cmd == "unbanall":
            count = len(self.banned_players) + len(self.banned_ips) + len(self.banned_hashes)
            self.banned_players.clear()
            self.banned_ips.clear()
            self.banned_hashes.clear()
            self._save_bans()
            print(f"[Console] Снято всех банов: {count}")
        elif cmd == "banlist":
            print(f"[Console] === СПИСОК БАНОВ ===")
            all_bans = list(self.banned_players) + list(self.banned_ips) + list(self.banned_hashes)
            if not all_bans:
                print("[Console] Банов нет")
            else:
                for i, ban in enumerate(all_bans, 1):
                    print(f"[Console] #{i}: {ban}")
            print(f"[Console] Всего банов: {len(all_bans)}")
            print("[Console] Используйте /unban #<номер> для разбана")
        elif cmd == "whitelist":
            if not args:
                print("Использование: /whitelist <add|remove|list> [ник]")
                return
            action = args[0].lower()
            if action == "add" and len(args) > 1:
                self.whitelist.add(args[1])
                self._save_whitelist()
                print(f"[Console] {args[1]} добавлен в вайтлист")
            elif action == "remove" and len(args) > 1:
                self.whitelist.discard(args[1])
                self._save_whitelist()
                print(f"[Console] {args[1]} удалён из вайтлиста")
            elif action == "list":
                print(f"[Console] Вайтлист ({len(self.whitelist)} игроков):")
                for nick in self.whitelist:
                    print(f"  - {nick}")
            else:
                print("Использование: /whitelist <add|remove|list> [ник]")
        elif cmd == "world":
            if not args:
                print("Использование: /world <create|list|load|delete|save> [имя]")
                return
            action = args[0].lower()
            if action == "create" and len(args) > 1:
                world_name = args[1]
                success, msg = self.create_world(world_name)
                print(f"[Console] {msg}")
            elif action == "list":
                worlds = self.get_world_list()
                print(f"[Console] Доступные миры ({len(worlds)}):")
                for w in worlds:
                    current = " (текущий)" if w == self.world_name else ""
                    print(f"  - {w}{current}")
            elif action == "load" and len(args) > 1:
                world_name = args[1]
                if world_name in self.get_world_list():
                    self._save_world()
                    self._load_world(world_name)
                    print(f"[Console] Мир '{world_name}' загружен")
                else:
                    print(f"[Console] Мир '{world_name}' не найден")
            elif action == "delete" and len(args) > 1:
                world_name = args[1]
                if world_name == self.world_name:
                    print("[Console] Нельзя удалить текущий мир")
                else:
                    success, msg = self.delete_world(world_name)
                    print(f"[Console] {msg}")
            elif action == "save":
                self._save_world()
                print(f"[Console] Мир '{self.world_name}' сохранён")
            else:
                print("Использование: /world <create|list|load|delete|save> [имя]")
        elif cmd == "save":
            self._save_world()
            print("[Console] Мир сохранён")
        elif cmd == "stop":
            print("[Console] Остановка сервера...")
            self._save_world()
            self._save_bans()
            self._save_whitelist()
            self.running = False
        elif cmd == "list":
            print(f"[Console] Игроки ({len(self.players)}):")
            for p in self.players.values():
                ip = getattr(p, 'ip', '?')
                print(f"  - {p.nickname} (ID:{p.id}, Role:{p.role}, IP:{ip})")
        elif cmd == "say":
            msg = " ".join(args)
            self.broadcast({"type":"chat","text":f"[Сервер] {msg}","color":[255,255,100]})
            print(f"[Console] [Сервер] {msg}")
        elif cmd in ["broadcast", "bc"]:
            msg = " ".join(args)
            self.broadcast({"type":"chat","text":f"[ОБЪЯВЛЕНИЕ] {msg}","color":[255,255,0]})
        elif cmd == "help":
            print("Команды консоли:")
            print("  /op, /deop, /player (или /pl), /guest — управление ролями")
            print("  /kick, /ban, /unban — управление игроками")
            print("  /unbanip, /unbancid, /unbanall — снятие банов")
            print("  /banlist — список банов (с номерами)")
            print("  /whitelist <add|remove|list> [ник] — управление вайтлистом")
            print("  /world <create|list|load|delete|save> [имя] — управление мирами")
            print("  /save, /stop, /list, /say, /broadcast (или /bc), /help")
        else:
            print(f"[Console] Неизвестная команда: /{cmd}")
    
    async def game_loop(self):
        tick_rate = self.config.get("tick_rate", 20)
        tick_time = 1.0 / tick_rate
        while self.running:
            start = time.time()
            self.day_timer += tick_time
            cycle = self.config["day_length"] + self.config["night_length"]
            if self.day_timer >= cycle:
                self.day_timer = 0
            self.save_timer += tick_time
            if self.save_timer >= self.config["save_interval"]:
                self.save_timer = 0
                self._save_world()
            elapsed = time.time() - start
            if elapsed < tick_time:
                await asyncio.sleep(tick_time - elapsed)
    
    async def start(self):
        self.running = True
        print(f"{'='*50}")
        print(f"Название: {self.config['server_name']}")
        print(f"Адрес: {self.config['host']}:{self.config['port']}")
        print(f"Текущий мир: {self.world_name}")
        print(f"Online mode: {self.config.get('online', False)}")
        print(f"Max players: {self.config.get('max_players', 10)}")
        print(f"{'='*50}")
        
        server = await asyncio.start_server(
            self.network_handler.handle_client,
            self.config['host'],
            self.config['port']
        )
        asyncio.create_task(self.game_loop())
        print("[Core] Сервер запущен. Введите /help для списка команд.")
        
        async with server:
            await server.serve_forever()
    
    def stop(self):
        self.running = False
        self._save_world()
        self._save_bans()
        self._save_whitelist()
        print("[Core] Сервер остановлен, данные сохранены")
