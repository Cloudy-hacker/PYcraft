# -*- coding: utf-8 -*-
import asyncio
from protocol import decode_message, encode_message

class NetworkHandler:
    def __init__(self, server):
        self.server = server
    
    async def handle_client(self, reader, writer):
        addr = writer.get_extra_info('peername')
        print(f"[Network] + {addr}")
        player = None
        try:
            while self.server.running:
                raw_length = await reader.read(4)
                if not raw_length: break
                msg_length = int.from_bytes(raw_length, 'big')
                raw_data = await reader.read(msg_length)
                if not raw_data: break
                data = decode_message(raw_data)
                await self.process(data, player, writer)
        except Exception as e:
            print(f"[Network] Error: {e}")
        finally:
            if player:
                self.server.remove_player(player)
            try: writer.close()
            except: pass
            print(f"[Network] - {addr}")
    
    async def process(self, data, player, writer):
        t = data.get("type")
        if t == "connect":
            nickname = data.get("nickname","Player")
            client_hash = data.get("client_hash")
            requested_world = data.get("world", "default")
            ip = writer.get_extra_info('peername')[0] if writer else None
            
            if requested_world not in self.server.get_world_list():
                self.server.create_world(requested_world)
            
            p, err = self.server.add_player(nickname, client_hash, writer, ip)
            if p is None:
                writer.write(encode_message({"type":"kick","message":err}))
                await writer.drain()
                writer.close()
                return
            player = p
            player.writer = writer
            writer.write(encode_message({
                "type":"welcome","player_id":player.id,"role":player.role,
                "world": requested_world
            }))
            writer.write(encode_message({
                "type":"world_state","tiles":{f"{k[0]},{k[1]}":v for k,v in self.server.world.tiles.items()}
            }))
            self.server.broadcast({"type":"player_join","player":player.to_dict()}, exclude=player)
            await writer.drain()
        elif t == "move" and player:
            player.update_position(data["x"], data["y"])
            self.server.broadcast({"type":"player_update","id":player.id,"x":player.x,"y":player.y}, exclude=player)
        elif t == "chat" and player:
            if player.nickname in self.server.muted_players:
                player.send({"type":"chat","text":"Вы замучены!","color":[255,100,100]})
                return
            text = data.get("text","")
            if text.startswith("/"):
                self._handle_command(player, text)
            else:
                self.server.broadcast({"type":"chat","text":f"<{player.nickname}> {text}","color":[200,200,200]})
        elif t == "disconnect" and player:
            writer.close()
        elif t == "command" and player and player.role == "op":
            self._handle_command(player, "/" + data.get("cmd","") + " " + " ".join(data.get("args",[])))
    
    def _handle_command(self, player, cmd_str):
        parts = cmd_str[1:].strip().split()
        if not parts: return
        cmd = parts[0].lower()
        args = parts[1:]
        
        if cmd == "op" and player.role == "op":
            if args:
                self.server.set_role(args[0], "op")
                self.server.broadcast({"type":"chat","text":f"{args[0]} теперь оператор!","color":[255,215,0]})
        elif cmd == "kick" and player.role == "op":
            if args:
                target = args[0]
                reason = " ".join(args[1:]) or "Без причины"
                kicked = False
                for p in list(self.server.players.values()):
                    if p.nickname == target:
                        p.send({"type":"kick","message":f"Вы были кикнуты: {reason}"})
                        try:
                            p.writer.close()
                        except:
                            pass
                        self.server.remove_player(p)
                        self.server.broadcast({"type":"chat","text":f"{target} кикнут: {reason}","color":[255,100,100]})
                        kicked = True
                        break
                if not kicked:
                    player.send({"type":"chat","text":f"Игрок {target} не найден","color":[255,100,100]})
        elif cmd == "ban" and player.role == "op":
            if args:
                target = args[0]
                reason = " ".join(args[1:]) or "Без причины"
                self.server.banned_players.add(target)
                for p in list(self.server.players.values()):
                    if p.nickname == target:
                        if getattr(p, 'ip', None):
                            self.server.banned_ips.add(p.ip)
                        if getattr(p, 'client_hash', None):
                            self.server.banned_hashes.add(p.client_hash)
                        p.send({"type":"kick","message":f"Вы забанены: {reason}"})
                        try:
                            p.writer.close()
                        except:
                            pass
                        self.server.remove_player(p)
                        break
                self.server._save_bans()
                self.server.broadcast({"type":"chat","text":f"{target} забанен: {reason}","color":[255,100,100]})
        elif cmd == "unban" and player.role == "op":
            if args:
                self.server.banned_players.discard(args[0])
                self.server._save_bans()
                self.server.broadcast({"type":"chat","text":f"{args[0]} разбанен","color":[100,255,100]})
        elif cmd == "save" and player.role == "op":
            self.server._save_world()
            self.server.broadcast({"type":"chat","text":"Мир сохранён!","color":[100,255,100]})
        elif cmd == "stop" and player.role == "op":
            self.server.broadcast({"type":"chat","text":"Сервер останавливается...","color":[255,100,100]})
            self.server.running = False
        elif cmd in ["broadcast","bc"] and player.role == "op" and args:
            msg = " ".join(args)
            self.server.broadcast({"type":"chat","text":f"[ОБЪЯВЛЕНИЕ] {msg}","color":[255,255,0]})
        elif cmd == "mute" and player.role == "op" and args:
            self.server.muted_players.add(args[0])
            self.server.broadcast({"type":"chat","text":f"{args[0]} замучен","color":[255,200,100]})
        elif cmd == "unmute" and player.role == "op" and args:
            self.server.muted_players.discard(args[0])
            self.server.broadcast({"type":"chat","text":f"{args[0]} размучен","color":[100,255,100]})
        elif cmd == "freeze" and player.role == "op" and args:
            self.server.frozen_players.add(args[0])
        elif cmd == "unfreeze" and player.role == "op" and args:
            self.server.frozen_players.discard(args[0])
        elif cmd == "guest" and player.role == "op" and args:
            self.server.set_role(args[0], "guest")
            self.server.broadcast({"type":"chat","text":f"{args[0]} теперь гость","color":[200,200,200]})
        elif cmd in ["player","pl"] and player.role == "op" and args:
            self.server.set_role(args[0], "player")
            self.server.broadcast({"type":"chat","text":f"{args[0]} теперь обычный игрок","color":[100,255,100]})
