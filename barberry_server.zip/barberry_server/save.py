# -*- coding: utf-8 -*-
import json, os
from datetime import datetime

class SaveManager:
    def __init__(self, worlds_dir="worlds"):
        self.worlds_dir = worlds_dir
        os.makedirs(worlds_dir, exist_ok=True)
    
    def save_world(self, world, world_name="default"):
        filepath = os.path.join(self.worlds_dir, f"{world_name}.json")
        data = world.to_dict()
        data["saved_at"] = datetime.now().isoformat()
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[Save] Мир '{world_name}' сохранён: {filepath}")
    
    def load_world(self, world_name="default"):
        from world import World
        filepath = os.path.join(self.worlds_dir, f"{world_name}.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print(f"[Save] Мир '{world_name}' загружен: {filepath}")
            return World.from_dict(data)
        else:
            print(f"[Save] Мир '{world_name}' не найден, создаём новый")
            return World()
