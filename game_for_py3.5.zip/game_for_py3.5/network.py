# -*- coding: utf-8 -*-
import socket, threading, json, logging
from constants import SERVER_PORT, DISCOVERY_PORT

logger = logging.getLogger(__name__)

def encode_message(data):
    message = json.dumps(data, ensure_ascii=False).encode('utf-8')
    return len(message).to_bytes(4, 'big') + message

def decode_message(raw):
    return json.loads(raw.decode('utf-8'))

class NetworkClient:
    def __init__(self):
        self.socket = None
        self.connected = False
        self.player_id = None
        self.incoming = []
        self.lock = threading.Lock()
        self.running = False
        self.recv_thread = None
    
    def connect(self, ip, port=SERVER_PORT):
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(5.0)
            self.socket.connect((ip, port))
            self.socket.settimeout(0.1)
            self.connected = True
            self.running = True
            self.recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
            self.recv_thread.start()
            return True
        except Exception as e:
            logger.error(f"Ошибка подключения: {e}")
            self.connected = False
            return False
    
    def _recv_loop(self):
        while self.running and self.connected:
            if self.socket is None:
                self.connected = False
                break
            try:
                raw_length = self.socket.recv(4)
                if not raw_length or len(raw_length) < 4:
                    self.connected = False
                    break
                msg_length = int.from_bytes(raw_length, 'big')
                raw_data = b""
                while len(raw_data) < msg_length:
                    packet = self.socket.recv(msg_length - len(raw_data))
                    if not packet:
                        self.connected = False
                        break
                    raw_data += packet
                if raw_data and self.connected:
                    data = decode_message(raw_data)
                    with self.lock:
                        self.incoming.append(data)
            except socket.timeout:
                continue
            except OSError as e:
                if e.winerror in (10038, 10053, 10054):
                    self.connected = False
                    break
                self.connected = False
                break
            except Exception:
                self.connected = False
                break
        self.disconnect()
    
    def send(self, data):
        if self.connected and self.socket is not None:
            try:
                self.socket.sendall(encode_message(data))
            except Exception:
                self.connected = False
    
    def get_messages(self):
        with self.lock:
            msgs = self.incoming[:]
            self.incoming.clear()
        return msgs
    
    def disconnect(self):
        self.running = False
        self.connected = False
        if self.socket is not None:
            try:
                self.socket.close()
            except Exception:
                pass
            self.socket = None

def discover_servers(timeout=2.0):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(timeout)
    sock.bind(('', 0))
    servers = []
    try:
        sock.sendto(b"DISCOVER", ('255.255.255.255', DISCOVERY_PORT))
        while True:
            try:
                data, addr = sock.recvfrom(1024)
                if data.startswith(b"BARBERRY:"):
                    servers.append({"ip": addr[0], "info": data.decode('utf-8')[9:]})
            except socket.timeout:
                break
    except Exception:
        pass
    finally:
        sock.close()
    return servers
