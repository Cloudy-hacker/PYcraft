# -*- coding: utf-8 -*-
import pygame, random, sys, math, os, time, logging, json
from constants import *
from items import Item, Slot, DroppedItem
from entities import Zombie
from network import NetworkClient
from sprites import Sprites, check_custom_sprites
from ui import MainMenu, DevMenu, CommandManager

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W,H))
        pygame.display.set_caption("PYcraft 2.0")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("arial", 14)
        self.font_small = pygame.font.SysFont("arial", 10)
        self.font_big = pygame.font.SysFont("arial", 24)
        
        self.custom_sprites_available = check_custom_sprites()
        self.use_custom_sprites = False
        self.sprites_warning = not self.custom_sprites_available
        self.sprites = Sprites(use_custom=False)
        
        self.main_menu = MainMenu(self)
        self.game_mode = "menu"
        self.client = NetworkClient()
        self.nickname = "Player"
        self.player_id = None
        self.role = "guest"
        self.px = 0; self.py = 0
        self.speed = 150
        self.cam_x = 0; self.cam_y = 0
        self.world = {}; self.doors = {}; self.grass = {}
        self.hotbar = [Slot() for _ in range(NUM_SLOTS)]
        self.inventory = [Slot() for _ in range(NUM_SLOTS*INV_ROWS)]
        self.sel = 0
        self.inv_open = False
        self.drag_item = None; self.drag_count = 0
        self.hp = 100; self.hunger = 100
        self.hunger_timer = 0
        self.regen_timer = 0.0
        self.zombies = []
        self.zombie_spawn_timer = 0.0
        self.dropped_items = []
        self.day_timer = 0; self.brightness = 1.0
        self.moving = False; self.walk_time = 0.0
        self.other_players = {}
        self.network_send_timer = 0.0
        self.q_held = False; self.q_timer = 0.0
        self.drone_mode = False
        self.drone_zoom = 1.0
        self.drone_tiles = 25
        self.drone_dragging = False
        self.drone_drag_start = (0, 0)
        self.drone_cam_offset = (0, 0)
        self.ALL_ITEMS = {}; self.RECIPES = []
        self._init_items()
        self.command_manager = CommandManager(self)
        self.chat_messages = []
        self.chat_input = ""
        self.chat_input_active = False
        self.debug = False
        self.kick_screen = False
        self.kick_message = ""
        self.death_screen = False
        self.death_timer = 0.0
        self.last_death_pos = (0, 0)
        self.tooltip_text = ""
        self.tooltip_timer = 0
        self.fps = 0; self.frame_count = 0; self.fps_time = 0
        self.last_debug_x = 0; self.last_debug_y = 0
        self.dev_menu = DevMenu(self)
        logger.info("PYcraft 2.0 запущен")
        if self.sprites_warning:
            logger.warning("Внимание! Спрайты не обнаружены!")
    
    def _init_items(self):
        self.ALL_ITEMS = {
            "Дерево": Item("Дерево", self.sprites.wood, T_TREE, True),
            "Камень": Item("Камень", self.sprites.stone_i, T_STONE, True),
            "Стена": Item("Стена", self.sprites.wall_i, T_WALL, True),
            "Фундамент": Item("Фундамент", self.sprites.found_i, T_FOUND, True),
            "Топор": Item("Топор", self.sprites.axe),
            "Кирка": Item("Кирка", self.sprites.pick),
            "Меч": Item("Меч", self.sprites.sword),
            "Ягоды": Item("Ягоды", self.sprites.berry_i, is_food=True, food_value=20),
            "Дверь": Item("Дверь", self.sprites.door_i, T_DOOR, True),
        }
        self.RECIPES = [
            {"name":"Топор","in":{"Дерево":3,"Камень":2},"out":("Топор",1)},
            {"name":"Кирка","in":{"Камень":3,"Дерево":2},"out":("Кирка",1)},
            {"name":"Меч","in":{"Камень":2,"Дерево":1},"out":("Меч",1)},
            {"name":"Стена x4","in":{"Дерево":2},"out":("Стена",4)},
            {"name":"Фундамент","in":{"Камень":8},"out":("Фундамент",1)},
            {"name":"Дверь","in":{"Дерево":6},"out":("Дверь",1)},
        ]
    
    def _generate_world(self):
        random.seed(42)
        self.grass = {}; self.world = {}; self.doors = {}
        self.dropped_items = []; self.zombies = []
        for ty in range(MAP_H):
            for tx in range(MAP_W):
                r = random.random()
                if r<0.3: self.grass[(tx,ty)]=C_BG_DARK
                elif r<0.5: self.grass[(tx,ty)]=C_BG_LIGHT
                else: self.grass[(tx,ty)]=C_BG
                r = random.random()
                if r<0.08: self.world[(tx,ty)]=T_TREE
                elif r<0.11: self.world[(tx,ty)]=T_STONE
                elif r<0.12: self.world[(tx,ty)]=T_BERRY
        cx,cy = MAP_W//2, MAP_H//2
        for dy in range(-3,4):
            for dx in range(-3,4):
                self.world.pop((cx+dx,cy+dy), None)
        self.world[(cx-2,cy)]=T_DEV; self.world[(cx+2,cy)]=T_DEV
        self.px = cx*TILE+TILE//2; self.py = cy*TILE+TILE//2
    
    def _save_world(self):
        """Сохранить мир, игрока и дропы (включая траву)"""
        try:
            world_data = {
                "tiles": {f"{k[0]},{k[1]}": v for k, v in self.world.items()},
                "doors": {f"{k[0]},{k[1]}": v for k, v in self.doors.items()},
                "grass": {f"{k[0]},{k[1]}": list(v) for k, v in self.grass.items()}
            }
            with open("world_save.json", 'w', encoding='utf-8') as f:
                json.dump(world_data, f, ensure_ascii=False)
            
            player_data = {
                "px": self.px, "py": self.py,
                "hp": self.hp, "hunger": self.hunger,
                "hotbar": [(s.item.name if s.item else None, s.count) for s in self.hotbar],
                "inventory": [(s.item.name if s.item else None, s.count) for s in self.inventory],
                "sel": self.sel,
                "day_timer": self.day_timer
            }
            with open("player_save.json", 'w', encoding='utf-8') as f:
                json.dump(player_data, f, ensure_ascii=False)
            
            drops_data = [
                {"x": d.x, "y": d.y, "item": d.item.name, "count": d.count}
                for d in self.dropped_items
            ]
            with open("drops_save.json", 'w', encoding='utf-8') as f:
                json.dump(drops_data, f, ensure_ascii=False)
            
            logger.info("Мир сохранён!")
        except Exception as e:
            logger.error(f"Ошибка сохранения: {e}")
    
    def _load_world(self):
        """Загрузить мир, игрока и дропы (включая траву)"""
        try:
            if os.path.exists("world_save.json"):
                with open("world_save.json", 'r', encoding='utf-8') as f:
                    world_data = json.load(f)
                
                self.world = {}
                for k, v in world_data.get("tiles", {}).items():
                    tx, ty = map(int, k.split(","))
                    self.world[(tx, ty)] = v
                
                self.doors = {}
                for k, v in world_data.get("doors", {}).items():
                    tx, ty = map(int, k.split(","))
                    self.doors[(tx, ty)] = v
                
                # ЗАГРУЗКА ТРАВЫ (исправление бага)
                self.grass = {}
                for k, v in world_data.get("grass", {}).items():
                    tx, ty = map(int, k.split(","))
                    self.grass[(tx, ty)] = tuple(v)
                
                logger.info(f"Мир загружен! Тайлов: {len(self.world)}, травы: {len(self.grass)}")
            else:
                logger.info("Сохранение не найдено, генерируем новый мир")
                self._generate_world()
            
            if os.path.exists("player_save.json"):
                with open("player_save.json", 'r', encoding='utf-8') as f:
                    player_data = json.load(f)
                
                self.px = player_data.get("px", self.px)
                self.py = player_data.get("py", self.py)
                self.hp = player_data.get("hp", 100)
                self.hunger = player_data.get("hunger", 100)
                self.sel = player_data.get("sel", 0)
                self.day_timer = player_data.get("day_timer", 0)
                
                for i, (item_name, count) in enumerate(player_data.get("hotbar", [])):
                    if i < len(self.hotbar) and item_name and item_name in self.ALL_ITEMS:
                        self.hotbar[i].item = self.ALL_ITEMS[item_name]
                        self.hotbar[i].count = count
                
                for i, (item_name, count) in enumerate(player_data.get("inventory", [])):
                    if i < len(self.inventory) and item_name and item_name in self.ALL_ITEMS:
                        self.inventory[i].item = self.ALL_ITEMS[item_name]
                        self.inventory[i].count = count
                
                logger.info("Игрок загружен!")
            
            if os.path.exists("drops_save.json"):
                with open("drops_save.json", 'r', encoding='utf-8') as f:
                    drops_data = json.load(f)
                
                self.dropped_items = []
                for d in drops_data:
                    if d["item"] in self.ALL_ITEMS:
                        item = self.ALL_ITEMS[d["item"]]
                        self.dropped_items.append(DroppedItem(d["x"], d["y"], item, d["count"]))
                
                logger.info(f"Загружено {len(self.dropped_items)} выпавших предметов")
            
        except Exception as e:
            logger.error(f"Ошибка загрузки: {e}")
            self._generate_world()
    
    def toggle_sprites(self):
        if self.use_custom_sprites:
            self.use_custom_sprites = False
            self.sprites = Sprites(use_custom=False)
        else:
            if self.custom_sprites_available:
                self.use_custom_sprites = True
                self.sprites = Sprites(use_custom=True)
            else:
                logger.warning("Пользовательские спрайты не найдены!")
        for name, item in self.ALL_ITEMS.items():
            sprite_map = {
                "Дерево": self.sprites.wood, "Камень": self.sprites.stone_i,
                "Стена": self.sprites.wall_i, "Фундамент": self.sprites.found_i,
                "Топор": self.sprites.axe, "Кирка": self.sprites.pick,
                "Меч": self.sprites.sword, "Ягоды": self.sprites.berry_i,
                "Дверь": self.sprites.door_i
            }
            if name in sprite_map:
                item.icon = sprite_map[name]
    
    def set_time_phase(self, phase):
        self.day_timer = phase * PHASE_LENGTH
    
    def spawn_zombie_nearby(self):
        angle = random.uniform(0, math.pi * 2)
        dist = 10 * TILE
        x = self.px + math.cos(angle) * dist
        y = self.py + math.sin(angle) * dist
        x = max(TILE, min(MAP_W*TILE-TILE, x))
        y = max(TILE, min(MAP_H*TILE-TILE, y))
        self.zombies.append(Zombie(x, y))
    
    def start_singleplayer(self, nickname):
        self.nickname = nickname
        self.game_mode = "single"
        self.role = "op"
        self._reset_game()
        self._load_world()
    
    def start_host(self, nickname):
        self.nickname = nickname
        self.game_mode = "host"
        self.role = "op"
        self._reset_game()
        self.main_menu.show_status("Хост запущен")
    
    def start_client(self, nickname, ip):
        if self.client.connect(ip):
            self.nickname = nickname
            self.game_mode = "client"
            self._reset_game()
            self.client.send({"type":"connect","nickname":nickname})
        else:
            self.main_menu.show_status("Не удалось подключиться!")
    
    def _reset_game(self):
        """Полный сброс состояния игры"""
        self.hp = 100; self.hunger = 100
        self.hunger_timer = 0; self.regen_timer = 0.0
        self.px = 0; self.py = 0
        self.cam_x = 0; self.cam_y = 0
        self.world = {}; self.doors = {}; self.grass = {}
        self.hotbar = [Slot() for _ in range(NUM_SLOTS)]
        self.inventory = [Slot() for _ in range(NUM_SLOTS*INV_ROWS)]
        self.sel = 0
        self.inv_open = False
        self.drag_item = None; self.drag_count = 0
        self.zombies = []; self.zombie_spawn_timer = 0.0
        self.dropped_items = []
        self.day_timer = 0; self.brightness = 1.0
        self.moving = False; self.walk_time = 0.0
        self.other_players = {}
        self.network_send_timer = 0.0
        self.q_held = False; self.q_timer = 0.0
        self.drone_mode = False; self.drone_cam_offset = (0, 0)
        self.chat_messages = []; self.chat_input = ""; self.chat_input_active = False
        self.debug = False; self.kick_screen = False; self.kick_message = ""
        self.death_screen = False; self.death_timer = 0.0
        self.dev_menu.close_menu()
    
    def add_chat_message(self, text, color=C_TEXT):
        self.chat_messages.append({"text":text,"color":color,"time":time.time()})
        if len(self.chat_messages)>10:
            self.chat_messages.pop(0)
    
    def _all_slots(self):
        for s in self.hotbar: yield s
        for s in self.inventory: yield s
    
    def _count_item(self, name):
        return sum(s.count for s in self._all_slots() if not s.empty() and s.item.name==name)
    
    def _pickup(self, item, amount):
        left = amount
        for s in self.hotbar:
            if left<=0: break
            if not s.empty() and s.item.name==item.name: left=s.add(item,left)
        for s in self.inventory:
            if left<=0: break
            if not s.empty() and s.item.name==item.name: left=s.add(item,left)
        for s in self.hotbar:
            if left<=0: break
            if s.empty(): left=s.add(item,left)
        for s in self.inventory:
            if left<=0: break
            if s.empty(): left=s.add(item,left)
    
    def _process_network(self):
        for msg in self.client.get_messages():
            t = msg.get("type")
            if t=="welcome":
                self.player_id = msg.get("player_id")
                self.role = msg.get("role","guest")
            elif t=="world_state":
                self.world = {}
                for k,v in msg.get("tiles",{}).items():
                    tx,ty = map(int,k.split(","))
                    self.world[(tx,ty)] = v
            elif t=="player_join":
                p = msg.get("player",{})
                self.other_players[p.get("id")] = {"x":p.get("x",0),"y":p.get("y",0),"name":p.get("nickname","")}
            elif t=="player_leave":
                self.other_players.pop(msg.get("player_id"), None)
            elif t=="player_update":
                pid = msg.get("id")
                if pid in self.other_players:
                    self.other_players[pid]["x"] = msg.get("x",0)
                    self.other_players[pid]["y"] = msg.get("y",0)
            elif t=="block_update":
                tx,ty = msg.get("tx"),msg.get("ty")
                b = msg.get("block",0)
                if b==0: self.world.pop((tx,ty), None)
                else: self.world[(tx,ty)] = b
            elif t=="chat":
                self.add_chat_message(msg.get("text",""), tuple(msg.get("color",C_TEXT)))
            elif t=="kick":
                self.kick_message = msg.get("message","Вы были отключены")
                self.kick_screen = True
            elif t=="role_update":
                self.role = msg.get("role","guest")
    
    def _send_position(self):
        if self.client.connected and self.player_id:
            self.client.send({"type":"move","x":self.px,"y":self.py})
    
    def _tile_under(self, pos):
        wx = pos[0]+self.cam_x; wy = pos[1]+self.cam_y
        return int(wx//TILE), int(wy//TILE)
    
    def _is_solid(self, tx, ty):
        block = self.world.get((tx, ty), T_EMPTY)
        if block in (T_WALL, T_STONE): return True
        if block == T_DOOR and self.doors.get((tx, ty), True): return True
        return False
    
    def _check_collision(self, px, py):
        half = TILE // 2
        player_tx = int(px) // TILE
        player_ty = int(py) // TILE
        for ty_check in range(player_ty - 1, player_ty + 2):
            for tx_check in range(player_tx - 1, player_tx + 2):
                if self._is_solid(tx_check, ty_check):
                    tile_rect = pygame.Rect(tx_check * TILE, ty_check * TILE, TILE, TILE)
                    player_rect = pygame.Rect(px - half, py - half, TILE - 4, TILE - 4)
                    if tile_rect.colliderect(player_rect):
                        return True
        return False
    
    def _check_zombie_collision(self, x, y):
        zombie_size = 20
        half = zombie_size // 2
        zombie_tx = int(x) // TILE
        zombie_ty = int(y) // TILE
        for ty_check in range(zombie_ty - 1, zombie_ty + 2):
            for tx_check in range(zombie_tx - 1, zombie_tx + 2):
                if self._is_solid(tx_check, ty_check):
                    tile_rect = pygame.Rect(tx_check * TILE, ty_check * TILE, TILE, TILE)
                    zombie_rect = pygame.Rect(x - half, y - half, zombie_size, zombie_size)
                    if tile_rect.colliderect(zombie_rect):
                        return True
        return False
    
    def _check_distance(self, pos):
        wx = pos[0]+self.cam_x; wy = pos[1]+self.cam_y
        dist = math.sqrt((wx - self.px)**2 + (wy - self.py)**2)
        return dist <= INTERACTION_DISTANCE
    
    def _eat_food(self):
        slot = self.hotbar[self.sel]
        if slot.empty() or not slot.item.is_food:
            return False
        food_val = slot.item.food_value
        self.hunger = min(100, self.hunger + food_val)
        slot.take(1)
        return True
    
    def _interact_door(self, pos):
        tx, ty = self._tile_under(pos)
        key = (tx, ty)
        if self.world.get(key) == T_DOOR:
            self.doors[key] = not self.doors.get(key, True)
            return True
        return False
    
    def _interact_dev(self, pos):
        tx, ty = self._tile_under(pos)
        key = (tx, ty)
        block = self.world.get(key, T_EMPTY)
        if block in (T_DEV, T_FAST_DEV):
            self.dev_menu.open_menu()
            return True
        return False
    
    def _drop_one(self):
        slot = self.hotbar[self.sel]
        if slot.empty(): return
        drop_x = self.px + random.uniform(-20, 20)
        drop_y = self.py + random.uniform(-20, 20)
        self.dropped_items.append(DroppedItem(drop_x, drop_y, slot.item, 1))
        slot.take(1)
    
    def _drop_full_stack(self):
        slot = self.hotbar[self.sel]
        if slot.empty(): return
        drop_x = self.px + random.uniform(-20, 20)
        drop_y = self.py + random.uniform(-20, 20)
        self.dropped_items.append(DroppedItem(drop_x, drop_y, slot.item, slot.count))
        slot.item = None; slot.count = 0
    
    def _click_dropped_item(self, pos):
        wx = pos[0]+self.cam_x; wy = pos[1]+self.cam_y
        for i, dropped in enumerate(self.dropped_items):
            dist = math.sqrt((wx - dropped.x)**2 + (wy - dropped.y)**2)
            if dist < 40:
                self._pickup(dropped.item, dropped.count)
                self.dropped_items.pop(i)
                return True
        return False
    
    def _attack_zombie(self, pos):
        if self.drone_mode: return False
        if not self._check_distance(pos): return False
        wx = pos[0]+self.cam_x; wy = pos[1]+self.cam_y
        slot = self.hotbar[self.sel]
        damage = 2 if (not slot.empty() and slot.item.name == "Меч") else 1
        for i, zombie in enumerate(self.zombies):
            dist = math.sqrt((wx - zombie.x)**2 + (wy - zombie.y)**2)
            if dist < 40:
                if zombie.take_damage(damage):
                    self.zombies.pop(i)
                return True
        return False
    
    def mine(self, pos):
        if self.drone_mode: return
        if not self._check_distance(pos): return
        tx,ty = self._tile_under(pos)
        key = (tx,ty)
        block = self.world.get(key, T_EMPTY)
        if block==T_TREE:
            self.world.pop(key, None); self._pickup(self.ALL_ITEMS["Дерево"], 1)
        elif block==T_STONE:
            self.world.pop(key, None); self._pickup(self.ALL_ITEMS["Камень"], 1)
        elif block==T_WALL:
            self.world.pop(key, None); self._pickup(self.ALL_ITEMS["Стена"], 1)
        elif block==T_FOUND:
            self.world.pop(key, None); self._pickup(self.ALL_ITEMS["Фундамент"], 1)
        elif block==T_BERRY:
            self.world.pop(key, None); self._pickup(self.ALL_ITEMS["Ягоды"], 1)
        elif block==T_FAST_DEV:
            self.world.pop(key, None)
            fast_dev_item = Item("Быстрый dev", self.sprites.fast_dev, T_FAST_DEV, True)
            self._pickup(fast_dev_item, 1)
        elif block==T_DEV:
            self.world.pop(key, None)
        elif block==T_DOOR:
            self.world.pop(key, None)
            self.doors.pop(key, None)
            self._pickup(self.ALL_ITEMS["Дверь"], 1)
    
    def place(self, pos):
        if self.drone_mode: return
        if not self._check_distance(pos): return
        slot = self.hotbar[self.sel]
        if slot.empty() or not slot.item.is_block: return
        tx,ty = self._tile_under(pos)
        key = (tx,ty)
        if tx<0 or tx>=MAP_W or ty<0 or ty>=MAP_H: return
        if key in self.world: return
        ptx = int(self.px)//TILE; pty = int(self.py)//TILE
        if tx==ptx and ty==pty: return
        block_type = slot.item.block_type
        self.world[key] = block_type
        if block_type == T_DOOR: self.doors[key] = True
        slot.take(1)
    
    def _on_death(self):
        death_x = self.px; death_y = self.py
        self.last_death_pos = (int(death_x), int(death_y))
        dropped_count = 0
        all_slots = list(self.hotbar) + list(self.inventory)
        for slot in all_slots:
            if not slot.empty():
                drop_x = death_x + random.uniform(-40, 40)
                drop_y = death_y + random.uniform(-40, 40)
                self.dropped_items.append(DroppedItem(drop_x, drop_y, slot.item, slot.count))
                dropped_count += slot.count
                slot.item = None; slot.count = 0
        self.add_chat_message("☠ Вы умерли!", (255, 80, 80))
        self.add_chat_message(f"Ваши вещи ({dropped_count} шт.) остались на месте смерти.", (255, 200, 100))
        self.hp = 100; self.hunger = 100
        cx, cy = MAP_W//2, MAP_H//2
        self.px = cx*TILE+TILE//2; self.py = cy*TILE+TILE//2
        self.inv_open = False; self.dev_menu.close_menu()
        self.drag_item = None; self.drag_count = 0
        self.q_held = False; self.q_timer = 0.0
        self.death_screen = True; self.death_timer = 3.0
    
    def _hotbar_rect(self, i):
        total_w = NUM_SLOTS*(SLOT_SIZE+SLOT_PAD)-SLOT_PAD
        ox = (W-total_w)//2; oy = H-SLOT_SIZE-10
        return pygame.Rect(ox+i*(SLOT_SIZE+SLOT_PAD), oy, SLOT_SIZE, SLOT_SIZE)
    
    def _inv_rect(self, idx):
        slot_size = 40; slot_pad = 4
        inv_width = 500; inv_height = 350
        inv_x = (W - inv_width) // 2; inv_y = (H - inv_height) // 2
        start_x = inv_x + 10; start_y = inv_y + 40
        row = idx // NUM_SLOTS; col = idx % NUM_SLOTS
        x = start_x + col * (slot_size + slot_pad)
        y = start_y + row * (slot_size + slot_pad)
        return pygame.Rect(x, y, slot_size, slot_size)
    
    def _can_craft(self, recipe):
        for name,need in recipe["in"].items():
            if self._count_item(name)<need: return False
        return True
    
    def _do_craft(self, recipe):
        for name,need in recipe["in"].items():
            left=need
            for s in self._all_slots():
                if left<=0: break
                if not s.empty() and s.item.name==name:
                    take=min(left,s.count); s.count-=take; left-=take
                    if s.count<=0: s.item=None; s.count=0
        out_name,out_count = recipe["out"]
        out_item = self.ALL_ITEMS.get(out_name)
        if out_item is None: return
        self._pickup(out_item, out_count)
    
    def _handle_inv_click(self, pos, button, shift):
        if button != 1: return
        for i in range(len(self.inventory)):
            if self._inv_rect(i).collidepoint(pos):
                self._slot_click(self.inventory[i], self.inventory, shift); return
        for i in range(NUM_SLOTS):
            if self._hotbar_rect(i).collidepoint(pos):
                self._slot_click(self.hotbar[i], self.hotbar, shift); return
        inv_width = 500; inv_height = 350
        inv_x = (W - inv_width) // 2; inv_y = (H - inv_height) // 2
        recipe_x = inv_x + inv_width - 200; recipe_y = inv_y + 35
        available_recipes = [r for r in self.RECIPES if self._can_craft(r)]
        for i, recipe in enumerate(available_recipes):
            recipe_rect = pygame.Rect(recipe_x, recipe_y + i * 45, 190, 40)
            if recipe_rect.collidepoint(pos):
                if self._can_craft(recipe):
                    self._do_craft(recipe)
                return
    
    def _slot_click(self, slot, owner, shift):
        if shift:
            target = self.inventory if owner is self.hotbar else self.hotbar
            if slot.empty(): return
            for s in target:
                if not s.empty() and s.item.name==slot.item.name and s.count<64:
                    space=64-s.count; take=min(slot.count,space)
                    s.count+=take; slot.count-=take
                    if slot.count<=0: slot.item=None; slot.count=0
                    return
            for s in target:
                if s.empty():
                    s.item=slot.item; s.count=slot.count
                    slot.item=None; slot.count=0
                    return
        else:
            if self.drag_item is None:
                if not slot.empty():
                    self.drag_item=slot.item; self.drag_count=slot.count
                    slot.item=None; slot.count=0
            else:
                if slot.empty():
                    slot.item=self.drag_item; slot.count=self.drag_count
                    self.drag_item=None; self.drag_count=0
                elif slot.item.name==self.drag_item.name:
                    space=64-slot.count; take=min(self.drag_count,space)
                    slot.count+=take; self.drag_count-=take
                    if self.drag_count<=0: self.drag_item=None; self.drag_count=0
                else:
                    old_item,old_count = slot.item,slot.count
                    slot.item=self.drag_item; slot.count=self.drag_count
                    self.drag_item=old_item; self.drag_count=old_count
    
    def run(self):
        while True:
            dt = self.clock.tick(FPS)/1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    if self.game_mode == "single":
                        self._save_world()
                    if self.client.connected:
                        self.client.send({"type":"disconnect"})
                        time.sleep(0.1)
                    self.client.disconnect()
                    pygame.quit(); sys.exit()
                
                if self.kick_screen:
                    if event.type == pygame.KEYDOWN:
                        if event.key in [pygame.K_ESCAPE, pygame.K_RETURN]:
                            self.kick_screen = False; self.kick_message = ""
                            if self.client.connected: self.client.disconnect()
                            self.game_mode = "menu"; self.other_players.clear()
                    continue
                
                if self.death_screen:
                    if event.type == pygame.KEYDOWN:
                        self.death_screen = False
                    continue
                
                if self.game_mode == "menu":
                    self.main_menu.handle_event(event)
                elif self.game_mode in ["single","host","client"]:
                    self._handle_game_event(event)
            
            if self.kick_screen:
                self._draw_kick_screen()
            elif self.death_screen:
                self._draw_death_screen(dt)
            elif self.game_mode == "menu":
                self.main_menu.draw()
            elif self.game_mode in ["single","host","client"]:
                if self.game_mode == "client":
                    self._process_network()
                self._update_game(dt)
                self._draw_game()
    
    def _handle_game_event(self, event):
        if event.type == pygame.KEYDOWN:
            if self.chat_input_active:
                if event.key == pygame.K_RETURN:
                    if self.chat_input.startswith("/"):
                        self.command_manager.execute(self.chat_input, self.role)
                    elif self.chat_input:
                        self.add_chat_message(f"<{self.nickname}> {self.chat_input}", (200,200,200))
                    self.chat_input = ""; self.chat_input_active = False
                elif event.key == pygame.K_ESCAPE:
                    self.chat_input_active = False; self.chat_input = ""
                elif event.key == pygame.K_BACKSPACE:
                    self.chat_input = self.chat_input[:-1]
                elif len(self.chat_input) < 100 and event.unicode.isprintable():
                    self.chat_input += event.unicode
                return
            
            if event.key == pygame.K_F3:
                self.debug = not self.debug; return
            if event.key == pygame.K_t:
                self.chat_input_active = True; return
            if event.key == pygame.K_F2:
                self.toggle_sprites(); return
            if event.key == pygame.K_f and not self.inv_open and not self.dev_menu.open:
                self.drone_mode = not self.drone_mode
                self.drone_cam_offset = (0, 0); return
            if event.key == pygame.K_e:
                if self.dev_menu.open:
                    self.dev_menu.close_menu()
                else:
                    self.inv_open = not self.inv_open
                    if not self.inv_open and self.drag_item:
                        self._pickup(self.drag_item, self.drag_count)
                        self.drag_item=None; self.drag_count=0
                return
            if event.key == pygame.K_q and not self.inv_open and not self.dev_menu.open and not self.drone_mode:
                self.q_held = True; self.q_timer = 0.0
                keys = pygame.key.get_pressed()
                if keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL]:
                    self._drop_full_stack()
                else:
                    self._drop_one()
                return
            if not self.inv_open and not self.dev_menu.open:
                if pygame.K_1 <= event.key <= pygame.K_9:
                    self.sel = event.key - pygame.K_1; return
            if event.key == pygame.K_ESCAPE:
                if self.game_mode == "single":
                    self._save_world()
                if self.client.connected:
                    self.client.send({"type":"disconnect"}); time.sleep(0.1)
                    self.client.disconnect()
                self.game_mode = "menu"
                self.other_players.clear()
                self.inv_open = False
                self.dev_menu.close_menu()
                self.drone_mode = False
                return
        
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_q:
                self.q_held = False; self.q_timer = 0.0
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.dev_menu.open:
                self.dev_menu.handle_click(event.pos)
            elif self.inv_open:
                shift = bool(pygame.key.get_mods() & pygame.KMOD_SHIFT)
                self._handle_inv_click(event.pos, event.button, shift)
            elif self.drone_mode:
                if event.button == 1:
                    self.drone_dragging = True
                    self.drone_drag_start = event.pos
            else:
                if event.button == 4: self.sel = (self.sel - 1) % NUM_SLOTS
                elif event.button == 5: self.sel = (self.sel + 1) % NUM_SLOTS
                elif event.button == 1:
                    if not self._click_dropped_item(event.pos):
                        if not self._attack_zombie(event.pos):
                            self.mine(event.pos)
                elif event.button == 3:
                    if not self._eat_food():
                        if not self._interact_door(event.pos):
                            if not self._interact_dev(event.pos):
                                self.place(event.pos)
        
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1 and self.drone_dragging:
                self.drone_dragging = False
        
        elif event.type == pygame.MOUSEMOTION:
            if self.drone_dragging:
                dx = event.pos[0] - self.drone_drag_start[0]
                dy = event.pos[1] - self.drone_drag_start[1]
                self.drone_cam_offset = (
                    self.drone_cam_offset[0] + dx,
                    self.drone_cam_offset[1] + dy
                )
                self.drone_drag_start = event.pos
    
    def _update_game(self, dt):
        self.frame_count += 1; self.fps_time += dt
        if self.fps_time >= 1.0:
            self.fps = self.frame_count; self.frame_count = 0; self.fps_time = 0
        
        self.day_timer += dt
        cycle = PHASE_LENGTH*4
        if self.day_timer >= cycle: self.day_timer = 0
        phase = self.day_timer/PHASE_LENGTH
        if phase<1: self.brightness = 0.3+0.7*(phase/1.0)
        elif phase<2: self.brightness = 1.0
        elif phase<3: self.brightness = 1.0-0.7*((phase-2)/1.0)
        else: self.brightness = 0.3
        
        is_night = phase >= 3
        if is_night and len(self.zombies) < MAX_ZOMBIES:
            self.zombie_spawn_timer += dt
            if self.zombie_spawn_timer >= 1.0/ZOMBIE_SPAWN_RATE:
                self.zombie_spawn_timer = 0
                angle = random.uniform(0, math.pi*2)
                dist = random.uniform(400, 600)
                x = self.px + math.cos(angle)*dist
                y = self.py + math.sin(angle)*dist
                x = max(TILE, min(MAP_W*TILE-TILE, x))
                y = max(TILE, min(MAP_H*TILE-TILE, y))
                self.zombies.append(Zombie(x,y))
        
        for zombie in self.zombies:
            zombie.update(dt, self.px, self.py, self)
            dist = math.sqrt((zombie.x-self.px)**2 + (zombie.y-self.py)**2)
            if dist < 30 and zombie.attack_cooldown <= 0:
                self.hp -= zombie.damage
                zombie.attack_cooldown = 1.0
            if phase < 2.5:
                zombie.burn_timer += dt
                if zombie.burn_timer >= 1.5:
                    zombie.burn_timer = 0.0
                    zombie.hp -= 1.5
                    if zombie.hp <= 0:
                        if zombie in self.zombies:
                            self.zombies.remove(zombie)
            else:
                zombie.burn_timer = 0.0
        
        keys = pygame.key.get_pressed()
        running = keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL]
        hunger_rate = 1.5 if running else 1.0
        self.hunger_timer += dt
        if self.hunger_timer >= 10:
            self.hunger_timer = 0
            self.hunger = max(0, self.hunger - hunger_rate)
        if self.hunger <= 0:
            self.hp = max(0, self.hp - 1)
        
        if self.hunger >= 60 and self.hp < 100:
            self.regen_timer += dt
            if self.regen_timer >= 1.0:
                self.regen_timer = 0.0
                heal_amount = min(5, 100 - self.hp)
                self.hp += heal_amount
        
        if self.hp <= 0:
            self._on_death()
            return
        
        if self.q_held and not self.inv_open and not self.dev_menu.open and not self.drone_mode:
            keys = pygame.key.get_pressed()
            ctrl_held = keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL]
            if not ctrl_held:
                self.q_timer += dt
                if self.q_timer >= Q_DROP_INTERVAL:
                    self.q_timer = 0.0
                    self._drop_one()
        
        if self.inv_open or self.dev_menu.open:
            return
        
        if not self.drone_mode:
            dx = dy = 0
            current_speed = self.speed * 2 if running else self.speed
            if keys[pygame.K_w] or keys[pygame.K_UP]: dy -= 1
            if keys[pygame.K_s] or keys[pygame.K_DOWN]: dy += 1
            if keys[pygame.K_a] or keys[pygame.K_LEFT]: dx -= 1
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx += 1
            
            self.moving = (dx != 0 or dy != 0)
            if self.moving: self.walk_time += dt * 8
            if dx != 0 and dy != 0: dx *= 0.707; dy *= 0.707
            
            new_px = self.px + dx * current_speed * dt
            new_py = self.py + dy * current_speed * dt
            
            if not self._check_collision(new_px, self.py):
                self.px = new_px
            if not self._check_collision(self.px, new_py):
                self.py = new_py
            
            half = TILE//2
            self.px = max(half, min(MAP_W*TILE-half, self.px))
            self.py = max(half, min(MAP_H*TILE-half, self.py))
            
            dist_moved = math.sqrt((self.px - self.last_debug_x)**2 + (self.py - self.last_debug_y)**2)
            if dist_moved >= 10 * TILE:
                self.last_debug_x = self.px
                self.last_debug_y = self.py
        
        if self.drone_mode:
            world_view = self.drone_tiles * TILE * 2
            base_cam_x = int(self.px - world_view / 2)
            base_cam_y = int(self.py - world_view / 2)
            self.cam_x = base_cam_x - self.drone_cam_offset[0]
            self.cam_y = base_cam_y - self.drone_cam_offset[1]
            self.drone_zoom = min(W / world_view, H / world_view)
        else:
            self.cam_x = int(self.px - W//2)
            self.cam_y = int(self.py - H//2)
            self.drone_zoom = 1.0
        
        if self.game_mode == "client":
            self.network_send_timer += dt
            if self.network_send_timer >= 0.05:
                self.network_send_timer = 0
                self._send_position()
    
    def _draw_game(self):
        self.screen.fill(C_BG)
        zoom = self.drone_zoom if self.drone_mode else 1.0
        
        if self.drone_mode:
            x0 = max(0, self.cam_x // TILE - 1)
            y0 = max(0, self.cam_y // TILE - 1)
            x1 = min(MAP_W, x0 + self.drone_tiles * 2 + 3)
            y1 = min(MAP_H, y0 + self.drone_tiles * 2 + 3)
        else:
            x0 = max(0, self.cam_x//TILE-1)
            y0 = max(0, self.cam_y//TILE-1)
            x1 = min(MAP_W, (self.cam_x+W)//TILE+2)
            y1 = min(MAP_H, (self.cam_y+H)//TILE+2)
        
        for ty in range(y0,y1):
            for tx in range(x0,x1):
                sx = int((tx*TILE-self.cam_x)*zoom)
                sy = int((ty*TILE-self.cam_y)*zoom)
                ts = int(TILE * zoom)
                gc = self.grass.get((tx,ty),C_BG)
                r=int(gc[0]*self.brightness)
                g=int(gc[1]*self.brightness)
                b=int(gc[2]*self.brightness)
                pygame.draw.rect(self.screen, (r,g,b), (sx,sy,ts,ts))
        
        current_time = time.time()
        for dropped in self.dropped_items:
            sx = int((dropped.x - self.cam_x)*zoom)
            sy = int((dropped.y - self.cam_y + dropped.get_bob_y(current_time))*zoom)
            shadow_y = int((dropped.y - self.cam_y + 8)*zoom)
            pygame.draw.ellipse(self.screen, (40,60,30), (sx-8, shadow_y, 16, 6))
            self.screen.blit(dropped.item.icon, (sx-12, sy-12))
            if dropped.count > 1:
                t = self.font_small.render(str(dropped.count), True, C_TEXT)
                self.screen.blit(t, (sx+8, sy+8))
        
        for ty in range(y0,y1):
            for tx in range(x0,x1):
                sx = int((tx*TILE-self.cam_x)*zoom)
                sy = int((ty*TILE-self.cam_y)*zoom)
                b = self.world.get((tx,ty),T_EMPTY)
                if b==T_TREE: self.screen.blit(self.sprites.tree, (sx,sy))
                elif b==T_STONE: self.screen.blit(self.sprites.stone, (sx,sy))
                elif b==T_WALL: self.screen.blit(self.sprites.wall, (sx,sy))
                elif b==T_FOUND: self.screen.blit(self.sprites.foundation, (sx,sy))
                elif b==T_BERRY: self.screen.blit(self.sprites.berry, (sx,sy))
                elif b==T_DEV: self.screen.blit(self.sprites.dev, (sx,sy))
                elif b==T_FAST_DEV: self.screen.blit(self.sprites.fast_dev, (sx,sy))
                elif b==T_DOOR:
                    ds = self.sprites.door_open if self.doors.get((tx,ty),False) else self.sprites.door_closed
                    self.screen.blit(ds, (sx,sy))
        
        for zombie in self.zombies:
            sx = int((zombie.x - self.cam_x)*zoom)
            sy = int((zombie.y - self.cam_y)*zoom)
            self.screen.blit(self.sprites.zombie, (sx-16, sy-16))
            hp_ratio = max(0, zombie.hp) / 10
            pygame.draw.rect(self.screen, (100,0,0), (sx-15, sy-22, 30, 4))
            pygame.draw.rect(self.screen, (0,200,0), (sx-15, sy-22, 30*hp_ratio, 4))
            if self.day_timer/PHASE_LENGTH < 2.5:
                pygame.draw.circle(self.screen, (255, 150, 0), (sx, sy-18), 3)
        
        for pid, pd in self.other_players.items():
            sx = int((pd["x"] - self.cam_x)*zoom)
            sy = int((pd["y"] - self.cam_y)*zoom)
            self.screen.blit(self.sprites.player2[0], (sx-16, sy-16))
            ns = self.font_small.render(pd["name"], True, C_TEXT)
            self.screen.blit(ns, (sx - ns.get_width()//2, sy-25))
        
        px = int((self.px - self.cam_x)*zoom)
        py = int((self.py - self.cam_y)*zoom)
        if self.drone_mode:
            pygame.draw.circle(self.screen, (255, 0, 0), (px, py), 8)
            pygame.draw.circle(self.screen, (200, 0, 0), (px, py), 8, 2)
        else:
            phase = 0 if self.moving and int(self.walk_time)%2==0 else 1
            self.screen.blit(self.sprites.player[phase], (px-16, py-16))
        
        self._draw_hotbar()
        self._draw_ui()
        
        if self.sprites_warning:
            warning_text = "Внимание! Спрайты не обнаружены! Игра работает с Python спрайтами."
            warning_surface = self.font.render(warning_text, True, (255, 0, 0))
            self.screen.blit(warning_surface, (10, H - 30))
        
        hint = "E-инв | F-дрон | F2-спрайты | F3-debug | T-чат | Q-выброс" if not self.inv_open and not self.dev_menu.open else "E - закрыть"
        if self.drone_mode: hint += " [ДРОН]"
        self.screen.blit(self.font.render(hint, True, C_TEXT), (10,10))
        
        if self.inv_open:
            self._draw_inventory()
            if self.drag_item:
                mx,my = pygame.mouse.get_pos()
                self.screen.blit(self.drag_item.icon, (mx-12,my-12))
                if self.drag_count>1:
                    t = self.font_small.render(str(self.drag_count), True, C_TEXT)
                    self.screen.blit(t, (mx+8,my+8))
        
        if self.dev_menu.open:
            self.dev_menu.draw()
        
        if self.debug:
            self._draw_debug()
        
        self._draw_chat()
        pygame.display.flip()
    
    def _draw_ui(self):
        pygame.draw.rect(self.screen, (100,0,0), (10, 50, 100, 10))
        pygame.draw.rect(self.screen, (200,0,0), (10, 50, self.hp, 10))
        hp_text = self.font_small.render(f"HP: {int(self.hp)}", True, C_TEXT)
        self.screen.blit(hp_text, (10, 40))
        pygame.draw.rect(self.screen, (100,100,0), (10, 70, 100, 10))
        pygame.draw.rect(self.screen, (200,200,0), (10, 70, self.hunger, 10))
        hunger_text = self.font_small.render(f"Голод: {int(self.hunger)}", True, C_TEXT)
        self.screen.blit(hunger_text, (10, 60))
        phase = self.day_timer / PHASE_LENGTH
        if phase < 1: time_text = "Утро"
        elif phase < 2: time_text = "День"
        elif phase < 3: time_text = "Вечер"
        else: time_text = "Ночь"
        time_surface = self.font_small.render(time_text, True, C_TEXT)
        self.screen.blit(time_surface, (10, 90))
    
    def _draw_hotbar(self):
        total_w = NUM_SLOTS*(SLOT_SIZE+SLOT_PAD)-SLOT_PAD
        ox = (W-total_w)//2; oy = H-SLOT_SIZE-10
        pygame.draw.rect(self.screen, C_HBAR, (ox-5, oy-5, total_w+10, SLOT_SIZE+10))
        for i in range(NUM_SLOTS):
            x = ox + i*(SLOT_SIZE+SLOT_PAD); y = oy
            pygame.draw.rect(self.screen, C_SLOT, (x,y,SLOT_SIZE,SLOT_SIZE))
            if i == self.sel:
                pygame.draw.rect(self.screen, C_SEL, (x,y,SLOT_SIZE,SLOT_SIZE), 3)
            slot = self.hotbar[i]
            if not slot.empty():
                self.screen.blit(slot.item.icon, (x+10, y+10))
                if slot.count > 1:
                    t = self.font.render(str(slot.count), True, C_TEXT)
                    self.screen.blit(t, (x+SLOT_SIZE-t.get_width()-2, y+SLOT_SIZE-t.get_height()-1))
            n = self.font.render(str(i+1), True, (160,160,160))
            self.screen.blit(n, (x+2, y+1))
    
    def _draw_inventory(self):
        inv_width = 500; inv_height = 350
        inv_x = (W - inv_width) // 2; inv_y = (H - inv_height) // 2
        pygame.draw.rect(self.screen, C_INV, (inv_x, inv_y, inv_width, inv_height))
        pygame.draw.rect(self.screen, (80,80,80), (inv_x, inv_y, inv_width, inv_height), 2)
        self.screen.blit(self.font.render("Инвентарь", True, C_TEXT), (inv_x + 10, inv_y + 10))
        slot_size = 40; slot_pad = 4
        start_x = inv_x + 10; start_y = inv_y + 40
        for i in range(len(self.inventory)):
            row = i // NUM_SLOTS; col = i % NUM_SLOTS
            x = start_x + col * (slot_size + slot_pad)
            y = start_y + row * (slot_size + slot_pad)
            pygame.draw.rect(self.screen, C_SLOT, (x, y, slot_size, slot_size))
            pygame.draw.rect(self.screen, (90,90,90), (x, y, slot_size, slot_size), 1)
            slot = self.inventory[i]
            if not slot.empty():
                self.screen.blit(slot.item.icon, (x+8, y+8))
                if slot.count > 1:
                    t = self.font_small.render(str(slot.count), True, C_TEXT)
                    self.screen.blit(t, (x+slot_size-t.get_width()-2, y+slot_size-t.get_height()-2))
        recipe_x = inv_x + inv_width - 200; recipe_y = inv_y + 10
        self.screen.blit(self.font.render("Крафт", True, C_TEXT), (recipe_x, recipe_y))
        available_recipes = [r for r in self.RECIPES if self._can_craft(r)]
        for i, recipe in enumerate(available_recipes):
            self._draw_recipe_compact(recipe, i, recipe_x, recipe_y + 25)
    
    def _draw_recipe_compact(self, recipe, i, x, y):
        can = self._can_craft(recipe)
        bg = C_REC_OK if can else C_REC_NO
        rect = pygame.Rect(x, y + i*45, 190, 40)
        pygame.draw.rect(self.screen, bg, rect)
        pygame.draw.rect(self.screen, (120,120,120), rect, 1)
        self.screen.blit(self.font_small.render(recipe["name"], True, C_TEXT), (x+5, y+i*45+3))
        ix = x + 5; iy = y + i*45 + 20
        for ing_name, ing_count in recipe["in"].items():
            ing_item = self.ALL_ITEMS.get(ing_name)
            if ing_item is None: continue
            self.screen.blit(ing_item.icon, (ix, iy))
            have = self._count_item(ing_name)
            color = (180,255,180) if have >= ing_count else (255,150,150)
            t = self.font_small.render(f"{ing_count}({have})", True, color)
            self.screen.blit(t, (ix+20, iy+4))
            ix += 60
        out_name, out_count = recipe["out"]
        out_item = self.ALL_ITEMS.get(out_name)
        if out_item:
            self.screen.blit(out_item.icon, (x + 160, y + i*45 + 10))
    
    def _draw_debug(self):
        pygame.draw.rect(self.screen, (0,0,0,180), (10, 10, 320, 240))
        pygame.draw.rect(self.screen, (100,100,100), (10, 10, 320, 240), 1)
        phase = self.day_timer/PHASE_LENGTH
        if phase<1: time_text = "Утро"
        elif phase<2: time_text = "День"
        elif phase<3: time_text = "Вечер"
        else: time_text = "Ночь"
        lines = [
            f"PYcraft 2.0 — Debug",
            f"FPS: {self.fps}",
            f"Игрок: ({self.px:.0f}, {self.py:.0f})",
            f"Камера: ({self.cam_x}, {self.cam_y})",
            f"Мир: {len(self.world)} тайлов",
            f"Трава: {len(self.grass)} тайлов",
            f"Зомби: {len(self.zombies)}",
            f"Время: {time_text} ({self.day_timer:.0f}с)",
            f"Яркость: {self.brightness:.2f}",
            f"HP: {int(self.hp)} | Голод: {int(self.hunger)}",
            f"Роль: {self.role}",
            f"Режим: {self.game_mode}",
            f"Дрон: {'вкл' if self.drone_mode else 'выкл'}",
            f"Спрайты: {'польз.' if self.use_custom_sprites else 'Python'}",
            f"Подключено: {self.client.connected}",
        ]
        for i, line in enumerate(lines):
            color = (0, 255, 0) if i == 0 else (200, 200, 200)
            t = self.font_small.render(line, True, color)
            self.screen.blit(t, (15, 15 + i*17))
    
    def _draw_chat(self):
        chat_x=10; chat_y=H-200
        for i,msg in enumerate(self.chat_messages[-5:]):
            c = msg["color"]
            ts = self.font_small.render(msg["text"],True,c)
            self.screen.blit(ts,(chat_x,chat_y+i*18))
        if self.chat_input_active:
            pygame.draw.rect(self.screen,(0,0,0,180),(chat_x,H-40,400,30))
            it = self.font_small.render(self.chat_input,True,C_TEXT)
            self.screen.blit(it,(chat_x+5,H-35))
    
    def _draw_kick_screen(self):
        self.screen.fill((80, 0, 0))
        title = self.font_big.render("Вы были отключены", True, (255, 80, 80))
        self.screen.blit(title, (W//2 - title.get_width()//2, 150))
        pygame.draw.line(self.screen, (150, 50, 50), (100, 220), (W-100, 220), 2)
        reason_lines = self.kick_message.split("\n")
        y = 260
        for line in reason_lines:
            txt = self.font.render(line, True, (255, 200, 200))
            self.screen.blit(txt, (W//2 - txt.get_width()//2, y))
            y += 25
        pygame.draw.line(self.screen, (150, 50, 50), (100, y+20), (W-100, y+20), 2)
        hint = self.font.render("Нажмите ESC или ENTER чтобы вернуться в меню", True, (200, 150, 150))
        self.screen.blit(hint, (W//2 - hint.get_width()//2, H - 80))
        pygame.display.flip()
    
    def _draw_death_screen(self, dt):
        self.death_timer -= dt
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((150, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        title = self.font_big.render("Вы умерли!", True, (255, 255, 255))
        self.screen.blit(title, (W//2 - title.get_width()//2, H//2 - 60))
        death_text = self.font.render(
            f"Ваши вещи остались на ({self.last_death_pos[0]}, {self.last_death_pos[1]})",
            True, (255, 200, 200)
        )
        self.screen.blit(death_text, (W//2 - death_text.get_width()//2, H//2))
        if self.death_timer > 0:
            timer_text = self.font.render(f"Возрождение через {int(self.death_timer)+1}...", True, (200, 200, 200))
            self.screen.blit(timer_text, (W//2 - timer_text.get_width()//2, H//2 + 40))
        else:
            hint = self.font.render("Нажмите любую клавишу чтобы продолжить", True, (200, 200, 200))
            self.screen.blit(hint, (W//2 - hint.get_width()//2, H//2 + 40))
            if self.death_timer < -2.0:
                self.death_screen = False
        pygame.display.flip()
